#ifndef FUNCS_H
#define FUNCS_H

#include "mpe_graphics.h"

double drand48();

#endif

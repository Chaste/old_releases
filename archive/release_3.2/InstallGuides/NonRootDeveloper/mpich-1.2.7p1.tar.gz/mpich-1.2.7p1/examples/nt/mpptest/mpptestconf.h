#ifndef MPPTESTCONF_H
#define MPPTESTCONF_H

/* Name of package */
#define PACKAGE "mpptest"

/* Version number of package */
#define VERSION "1.0"

#define restrict
#define HAVE_STDLIB_H
#define HAVE_STDIO_H
#define HAVE_STRING_H

#endif

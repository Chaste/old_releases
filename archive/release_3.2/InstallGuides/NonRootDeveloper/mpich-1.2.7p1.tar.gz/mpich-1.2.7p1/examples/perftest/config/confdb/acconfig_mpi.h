/* Define if MPI_xxx_f2c and c2f routines defined */
#undef HAVE_MPI_F2C

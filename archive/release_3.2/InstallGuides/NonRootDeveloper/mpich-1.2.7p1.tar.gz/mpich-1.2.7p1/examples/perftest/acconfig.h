#undef HAVE_SHMALLOC
#undef restrict
#undef HAVE_LONG_LONG

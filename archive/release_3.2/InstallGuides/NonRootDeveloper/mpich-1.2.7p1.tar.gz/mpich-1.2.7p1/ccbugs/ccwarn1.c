#include <stdio.h>
main()
{
printf( "%s\n", CONFIGURE_ARGS_CLEAN );
return 0;
}

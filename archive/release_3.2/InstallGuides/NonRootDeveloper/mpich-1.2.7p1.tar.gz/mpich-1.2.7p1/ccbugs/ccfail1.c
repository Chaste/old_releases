main()
{
exit(recur(0,1));
}
recur(a,b)
int a,b;
{int c;
c = 0; 
if ((b!=1)&&(c=1)) return c; 
return c;
}

typedef struct M { 
    int c;
    };

int Msize ( d, size )
struct M  *d;
long  *size;
{
int m;
if (( ( d->c != 1 ) && (m = 2 )) || (!(size) && (m = 6))) 
    return m; 
return 0; 
}

int main()
{
return 0;
}
